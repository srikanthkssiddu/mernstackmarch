let getElements = document.getElementsByTagName("section");

console.log(getElements);

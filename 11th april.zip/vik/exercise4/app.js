// write("string") in document

document.write("string");

//getElementById()

let getId = document.getElementById("getId");
console.log(getId);

//getElementsByName()

let getName = document.getElementsByName("getName");
console.log(getName);

//getElementsByTagName()

let getTagName = document.getElementsByTagName("div");
console.log(getTagName);

//getElementsByClassName()

let getClass = document.getElementsByClassName("getClass");
console.log(getClass);

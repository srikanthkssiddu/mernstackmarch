let root = document.getElementById("root");

root.innerHTML = "Hello There";
